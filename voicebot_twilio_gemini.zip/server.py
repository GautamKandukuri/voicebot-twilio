
from flask import Flask, request, Response
from google.cloud import bigquery
import json

app = Flask(__name__)
config = json.load(open("config.json"))
bq_client = bigquery.Client(project=config["gcp_project_id"])

def gemini_reply(prompt):
    return "Hello, this is your Telecom assistant. Do you consent to receive service plan updates?"

@app.route("/voice", methods=["POST"])
def voice_flow():
    response = gemini_reply("start call")
    twiml = "<?xml version='1.0' encoding='UTF-8'?><Response><Say>" + response + "</Say><Record action='/record' maxLength='10'/></Response>"
    return Response(twiml, mimetype="text/xml")

@app.route("/record", methods=["POST"])
def record():
    recording_url = request.values.get("RecordingUrl", "")
    transcript = "User consent captured (speech-to-text goes here)"

    table_id = f"{config['gcp_project_id']}.{config['bigquery_dataset']}.{config['bigquery_table']}"
    row = {
        "phone": config["twilio_to_number"],
        "consent": True,
        "transcript": transcript,
        "recording_url": recording_url
    }
    bq_client.insert_rows_json(table_id, [row])

    twiml = "<?xml version='1.0' encoding='UTF-8'?><Response><Say>Thank you. Goodbye.</Say></Response>"
    return Response(twiml, mimetype="text/xml")

if __name__ == "__main__":
    app.run(port=5000)
